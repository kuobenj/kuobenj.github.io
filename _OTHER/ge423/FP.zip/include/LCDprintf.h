void LCDvPrintfLine(unsigned char line, char *format, va_list ap);
void LCDPrintfLine(unsigned char line, char *format, ...);
