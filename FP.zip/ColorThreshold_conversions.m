Orange_S_center = (177+255)/2
Orange_S_rad = 255-Orange_S_center
Orange_V_center = (212+255)/2
Orange_V_rad = 255-Orange_V_center
Orange_H_center = (240+266)/2
Orange_H_rad = 266-Orange_V_center

Blue_S_center =( 87+255)/2
Blue_S_rad = 255-Blue_S_center
Blue_V_center = (131+255)/2
Blue_V_rad = 255-Blue_V_center
Blue_H_center = (144+181)/2
Blue_H_rad = 181-Blue_V_center


