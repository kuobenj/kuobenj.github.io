Orange2 Selected Threshold: H [0:11,240:255], S [177:255], V [212:255]
Blue1 Selected Threshold: H [144:181], S [87:255], V [131:255]